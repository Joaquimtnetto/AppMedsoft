(function () {
    function headers() {
        return {
            'Content-Type': 'application/json',
            'X-DB-PATH': localStorage.getItem('db_path') || ''
        };
    }

    function api(method, body) {
        return CrudUI.request('/api/configuracao', {
            method: method,
            headers: headers(),
            body: body ? JSON.stringify(body) : undefined
        });
    }

    function testEmail(body) {
        return CrudUI.request('/api/configuracao/testar-email', {
            method: 'POST',
            headers: headers(),
            body: JSON.stringify(body)
        });
    }

    function fieldValue(form, name, fallback) {
        var field = form.elements[name];
        if (!field) return fallback == null ? '' : fallback;
        if (field.type === 'checkbox') return field.checked;
        return field.value;
    }

    function setFieldValue(form, name, value) {
        var field = form.elements[name];
        if (!field) return;
        if (field.type === 'checkbox') field.checked = !!value;
        else field.value = value || '';
    }

    function setTextoOptions(form, options) {
        var page = document.getElementById('configuracao-page');
        var expectedType = page && page.dataset.configuracaoTela === 'whatsapp' ? 'Z' : 'E';
        var channelOptions = (options || []).filter(function (option) {
            return !option.tipo || option.tipo === expectedType;
        });
        form.querySelectorAll('.configuracao-texto-select').forEach(function (select) {
            var current = select.value;
            select.innerHTML = '<option value="">Selecione</option>' + channelOptions.map(function (option) {
                return '<option value="' + CrudUI.escapeHtml(option.value) + '">' +
                    CrudUI.escapeHtml(option.label) + '</option>';
            }).join('');
            select.value = current;
        });
    }

    function setFormValues(form, values) {
        Object.keys(values || {}).forEach(function (name) {
            var field = form.elements[name];
            if (!field) return;
            if (field.type === 'checkbox') field.checked = !!values[name];
            else if (name !== 'smtp_senha' && name !== 'whatsapp_token') field.value = values[name] || '';
        });
        if (form.elements.smtp_senha) {
            form.elements.smtp_senha.placeholder = values.possui_smtp_senha
                ? 'Senha já cadastrada — deixe vazio para manter' : 'Informe a senha';
        }
        if (form.elements.whatsapp_token) {
            form.elements.whatsapp_token.placeholder = values.possui_whatsapp_token
                ? 'Token já cadastrado — deixe vazio para manter' : 'Informe o token';
        }
        if (form.elements.whatsapp_modo) {
            form.elements.whatsapp_modo.value = values.whatzapsimplificado ? 'simplificado' : 'business';
        }
        updateWhatsappMode(form);
    }

    function updateWhatsappMode(form) {
        if (!form.elements.whatsapp_modo) return;
        var simplified = form.elements.whatsapp_modo.value === 'simplificado';
        form.querySelectorAll('.whatsapp-business-only').forEach(function (field) {
            field.hidden = simplified;
        });
        var note = form.querySelector('.configuracao-simplified-note');
        if (note) note.hidden = !simplified;
    }

    function formValues(form, currentValues) {
        var base = Object.assign({
            smtp_host: '',
            smtp_porta: '',
            smtp_usuario: '',
            smtp_senha: '',
            smtp_remetente: '',
            smtp_tls: true,
            smtp_ssl: false,
            whatsapp_remetente: '5521986496127',
            whatsapp_phone_number_id: '',
            whatsapp_token: '',
            whatsapp_api_version: '',
            whatsapp_template: '',
            whatsapp_idioma: 'pt_BR',
            whatzapsimplificado: false,
            autlembraagendaemail: '',
            autlembraretagendaemail: '',
            autlembraniveremail: '',
            autlembraeventemail: '',
            textolembraagendaemail: '',
            textolembraretagendaemail: '',
            textolembraniveremail: '',
            textolembraeventemail: '',
            autlembraagendawhatzap: '',
            autlembraretagendawhatzap: '',
            autlembraniverwahtzap: '',
            autlembraeventowahtzap: '',
            textolembraagendawahtzap: '',
            textolembraretagendawahtzap: '',
            textolembraniverwahtzap: '',
            textolembraeventwahtzap: ''
        }, currentValues || {});
        return {
            smtp_host: fieldValue(form, 'smtp_host', base.smtp_host),
            smtp_porta: fieldValue(form, 'smtp_porta', base.smtp_porta),
            smtp_usuario: fieldValue(form, 'smtp_usuario', base.smtp_usuario),
            smtp_senha: fieldValue(form, 'smtp_senha', ''),
            smtp_remetente: fieldValue(form, 'smtp_remetente', base.smtp_remetente),
            smtp_tls: fieldValue(form, 'smtp_tls', base.smtp_tls),
            smtp_ssl: fieldValue(form, 'smtp_ssl', base.smtp_ssl),
            whatsapp_remetente: fieldValue(form, 'whatsapp_remetente', base.whatsapp_remetente),
            whatsapp_phone_number_id: fieldValue(form, 'whatsapp_phone_number_id', base.whatsapp_phone_number_id),
            whatsapp_token: fieldValue(form, 'whatsapp_token', ''),
            whatsapp_api_version: fieldValue(form, 'whatsapp_api_version', base.whatsapp_api_version),
            whatsapp_template: fieldValue(form, 'whatsapp_template', base.whatsapp_template),
            whatsapp_idioma: fieldValue(form, 'whatsapp_idioma', base.whatsapp_idioma),
            whatzapsimplificado: form.elements.whatsapp_modo
                ? form.elements.whatsapp_modo.value === 'simplificado'
                : !!base.whatzapsimplificado,
            autlembraagendaemail: fieldValue(form, 'autlembraagendaemail', base.autlembraagendaemail),
            autlembraretagendaemail: fieldValue(form, 'autlembraretagendaemail', base.autlembraretagendaemail),
            autlembraniveremail: fieldValue(form, 'autlembraniveremail', base.autlembraniveremail),
            autlembraeventemail: fieldValue(form, 'autlembraeventemail', base.autlembraeventemail),
            textolembraagendaemail: fieldValue(form, 'textolembraagendaemail', base.textolembraagendaemail),
            textolembraretagendaemail: fieldValue(form, 'textolembraretagendaemail', base.textolembraretagendaemail),
            textolembraniveremail: fieldValue(form, 'textolembraniveremail', base.textolembraniveremail),
            textolembraeventemail: fieldValue(form, 'textolembraeventemail', base.textolembraeventemail),
            autlembraagendawhatzap: fieldValue(form, 'autlembraagendawhatzap', base.autlembraagendawhatzap),
            autlembraretagendawhatzap: fieldValue(form, 'autlembraretagendawhatzap', base.autlembraretagendawhatzap),
            autlembraniverwahtzap: fieldValue(form, 'autlembraniverwahtzap', base.autlembraniverwahtzap),
            autlembraeventowahtzap: fieldValue(form, 'autlembraeventowahtzap', base.autlembraeventowahtzap),
            textolembraagendawahtzap: fieldValue(form, 'textolembraagendawahtzap', base.textolembraagendawahtzap),
            textolembraretagendawahtzap: fieldValue(form, 'textolembraretagendawahtzap', base.textolembraretagendawahtzap),
            textolembraniverwahtzap: fieldValue(form, 'textolembraniverwahtzap', base.textolembraniverwahtzap),
            textolembraeventwahtzap: fieldValue(form, 'textolembraeventwahtzap', base.textolembraeventwahtzap)
        };
    }

    async function init() {
        var page = document.getElementById('configuracao-page');
        if (!page || page.dataset.initialized === 'true') return;
        page.dataset.initialized = 'true';
        var form = document.getElementById('configuracao-form');
        var status = document.getElementById('configuracao-status');
        var submitButton = form.querySelector('[type="submit"]');
        var passwordInput = form.elements.smtp_senha;
        var passwordToggle = document.getElementById('toggle-smtp-senha');
        var testEmailButton = document.getElementById('configuracao-test-email');
        var testEmailResult = document.getElementById('configuracao-email-test-result');
        var currentValues = {};

        if (passwordToggle && passwordInput) passwordToggle.onclick = function () {
            var showing = passwordInput.type === 'text';
            passwordInput.type = showing ? 'password' : 'text';
            passwordToggle.title = showing ? 'Exibir senha' : 'Ocultar senha';
            passwordToggle.setAttribute('aria-label', passwordToggle.title);
            passwordToggle.setAttribute('aria-pressed', String(!showing));
            passwordToggle.querySelector('i').className = showing
                ? 'fa-solid fa-eye' : 'fa-solid fa-eye-slash';
            passwordInput.focus();
        };

        if (form.elements.smtp_tls) form.elements.smtp_tls.onchange = function () {
            if (this.checked) form.elements.smtp_ssl.checked = false;
        };
        if (form.elements.smtp_ssl) form.elements.smtp_ssl.onchange = function () {
            if (this.checked) form.elements.smtp_tls.checked = false;
        };
        if (form.elements.whatsapp_modo) {
            Array.from(form.elements.whatsapp_modo).forEach(function (option) {
                option.onchange = function () { updateWhatsappMode(form); };
            });
        }

        if (testEmailButton) testEmailButton.onclick = async function () {
            testEmailButton.disabled = true;
            testEmailResult.innerHTML = '<div class="crud-loading">Testando conexão...</div>';
            try {
                var result = await testEmail(formValues(form, currentValues));
                var details = (result.responses || []).map(function (response) {
                    return '<small>' + CrudUI.escapeHtml(response) + '</small>';
                }).join('');
                testEmailResult.innerHTML = '<div class="crud-success">' +
                    CrudUI.escapeHtml(result.message) + details + '</div>';
            } catch (error) {
                testEmailResult.innerHTML = '<div class="crud-error">' +
                    CrudUI.escapeHtml(error.message || 'Falha ao testar a conexão SMTP.') + '</div>';
            } finally {
                testEmailButton.disabled = false;
            }
        };

        try {
            var data = await api('POST');
            currentValues = data.configuracao || {};
            setTextoOptions(form, data.textos || []);
            setFormValues(form, currentValues);
        } catch (error) {
            status.innerHTML = '<div class="crud-error">' + CrudUI.escapeHtml(error.message) + '</div>';
            submitButton.disabled = true;
        }

        form.onsubmit = async function (event) {
            event.preventDefault();
            submitButton.disabled = true;
            try {
                var result = await api('PUT', formValues(form, currentValues));
                setFieldValue(form, 'smtp_senha', '');
                setFieldValue(form, 'whatsapp_token', '');
                CrudUI.notify(result.message || 'Configurações salvas com sucesso.');
                var refreshed = await api('POST');
                currentValues = refreshed.configuracao || {};
                setTextoOptions(form, refreshed.textos || []);
                setFormValues(form, currentValues);
            } catch (error) {
                CrudUI.notify(error.message || 'Não foi possível salvar as configurações.', 'error');
            } finally {
                submitButton.disabled = false;
            }
        };
    }

    window.ConfiguracaoMedsoft = {init: init};
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
}());
