
from medsoft_core import get_db_connection
from build_info import BUILD_DATETIME, BUILD_VERSION
import config
from message_log import log_sent_message
from config import SECRET_KEY
# Importa o Blueprint de consulta_paciente
from consulta_paciente import consulta_paciente_bp
from consultas_routes import consultas_bp
from agenda import agenda_bp
from agenda_api import agenda_api_bp
from paciente_api import paciente_api_bp
from plano_api import plano_api_bp
from prof_saude_api import prof_saude_api_bp
from clinica_api import clinica_api_bp
from usuario_api import usuario_api_bp
from configuracao_api import configuracao_api_bp
from baileys_api import baileys_api_bp
from exame_api import exame_api_bp
from perfil_api import perfil_api_bp
from empresa_api import empresa_api_bp
from procedimento_api import procedimento_api_bp
from faturamento_api import faturamento_api_bp
from mensagens_api import mensagens_api_bp
from internal_chat_api import internal_chat_api_bp

db_path_global = None
usuario_global = None
empresa_global = None

def get_user_empresa_db(login, senha):
    # A tabela atual é `ic_usuario_geral` e os campos de autenticação são `login` e `senha`.
    # Muitos esquemas não possuem a coluna `nome_medico`; para evitar erro, retornamos
    # um valor nulo para `nome_medico` quando a coluna não existir.
    con = get_db_connection()
    cur = con.cursor()
    cur.execute("""
        SELECT ug.idusuario,
               ug.idempresa,
               ug.nome,
               eg.database,
               eg.nome as empresa,
               NULL::text as nome_medico,
               COALESCE(perfil.nome, perfil.descricao, '') as perfil
        FROM ic_usuario_geral ug
        LEFT JOIN ic_empresa_geral eg ON eg.idempresa = ug.idempresa
        LEFT JOIN ic_perfil_geral perfil ON perfil.idperfil = ug.idperfil
        WHERE ug.login=%s
          AND ug.senha=%s
          AND ug.ativo=TRUE
          AND (COALESCE(eg.ativo, FALSE)=TRUE OR UPPER(COALESCE(perfil.nome, perfil.descricao, '')) = 'MASTER')
    """, (login, senha))
    user = cur.fetchone()
    con.close()
    if not user:
        return (None, None, None, None, None, None, None)
    idusuario, idempresa, nome, db_path, empresa_nome, nome_medico, perfil = user
    if not db_path and (perfil or '').strip().upper() == 'MASTER' and not idempresa:
        idempresa = 0
        db_path = config.PG_DB
        empresa_nome = ''
    elif not db_path and (perfil or '').strip().upper() == 'MASTER':
        db_path = config.PG_DB
        empresa_nome = empresa_nome or ''
    return idusuario, idempresa, nome, db_path, empresa_nome, nome_medico, perfil


def get_company_usage_limit(company_id, today=None):
    """Retorna (permitido, data_limite) conforme a vigencia do plano da empresa."""
    try:
        company_id = int(company_id or 0)
    except (TypeError, ValueError):
        company_id = 0
    if company_id <= 0:
        return True, None

    connection = get_db_connection()
    try:
        with connection.cursor() as cursor:
            cursor.execute('''
                SELECT empresa.datainicio, plano.diasmax
                FROM public.ic_empresa_geral empresa
                LEFT JOIN public.ic_plano_geral plano ON plano.idplano = empresa.idplano
                WHERE empresa.idempresa = %s
                LIMIT 1
            ''', (company_id,))
            row = cursor.fetchone()
    finally:
        connection.close()

    # O cadastro atual representa o campo vazio como NULL ou zero.
    if not row or row[1] in (None, ''):
        return True, None
    try:
        maximum_days = int(row[1])
    except (TypeError, ValueError):
        maximum_days = 0
    if maximum_days <= 0:
        return True, None

    start_date = row[0]
    if start_date is None:
        raise ValueError('A data de inicio da empresa nao foi informada.')
    if isinstance(start_date, datetime.datetime):
        start_date = start_date.date()
    limit_date = start_date + datetime.timedelta(days=maximum_days)
    reference_date = today or datetime.date.today()
    return reference_date <= limit_date, limit_date

import os
import secrets
import sys

from flask import Flask, request, jsonify, render_template, session, redirect, url_for
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from werkzeug.exceptions import HTTPException
import smtplib
from email.message import EmailMessage
import logging
from consultas_routes import consultas_bp
import traceback
import datetime

if getattr(sys, 'frozen', False):
    # No executável, a versão corresponde à data real de geração do arquivo.
    executable_time = datetime.datetime.fromtimestamp(
        os.path.getmtime(sys.executable)
    ).astimezone()
    BUILD_DATETIME = executable_time.strftime('%d/%m/%Y %H:%M')
    BUILD_VERSION = executable_time.strftime('%Y%m%d%H%M%S')
else:
    startup_time = datetime.datetime.now().astimezone()
    BUILD_DATETIME = startup_time.strftime('%d/%m/%Y %H:%M')
    BUILD_VERSION = startup_time.strftime('%Y%m%d%H%M%S')



# Função para obter o caminho dos recursos (templates/static) para PyInstaller
def resource_path(relative_path):
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    return os.path.join(project_root, relative_path)

from flask import send_from_directory


# No executável, os recursos são extraídos pelo PyInstaller em sys._MEIPASS.
template_folder = resource_path('templates')
static_folder = resource_path('static')



app = Flask(
    __name__,
    template_folder=template_folder,
    static_folder=static_folder
)
app.secret_key = SECRET_KEY
app.json.ensure_ascii = False
app.config['PERMANENT_SESSION_LIFETIME'] = config.SESSION_LIFETIME
app.config['SESSION_REFRESH_EACH_REQUEST'] = True
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['TEMPLATES_AUTO_RELOAD'] = True
app.jinja_env.auto_reload = True


@app.after_request
def enforce_utf8_response(response):
    if response.mimetype in ('application/json', 'text/html', 'text/plain'):
        response.headers['Content-Type'] = f'{response.mimetype}; charset=utf-8'
    return response


@app.errorhandler(Exception)
def handle_unexpected_error(error):
    if isinstance(error, HTTPException):
        return error
    logging.exception('Erro inesperado na aplicação Flask:', exc_info=error)
    return 'Internal Server Error', 500

PUBLIC_ENDPOINTS = {
    'index',
    'login',
    'esqueci_senha_form',
    'esqueci_senha_post',
    'reset_password_form',
    'reset_password_post',
    'agenda_api.confirm_appointment',
    'help_html',
    'static',
}


def _has_valid_session():
    company_id = session.get('idempresa')
    legacy_company_id = session.get('codclin')
    if company_id not in (None, '') and legacy_company_id not in (None, ''):
        try:
            if int(company_id) != int(legacy_company_id):
                return False
        except (TypeError, ValueError):
            return False
    if company_id in (None, ''):
        company_id = legacy_company_id
    required_values = (
        session.get('usuario'),
        session.get('idusuario'),
        company_id,
        session.get('db_path'),
    )
    is_valid = (
        session.get('authenticated') is True and
        all(value not in (None, '') for value in required_values)
    )
    if is_valid and session.get('idempresa') in (None, ''):
        session['idempresa'] = company_id
    return is_valid


@app.before_request
def require_authentication():
    if request.endpoint in PUBLIC_ENDPOINTS:
        return None
    if _has_valid_session():
        return None
    session.clear()
    if request.path.startswith('/api/'):
        return jsonify({'success': False, 'message': 'Sessão expirada. Faça login novamente.'}), 401
    return redirect(url_for('index'))


EDIT_ENDPOINT_MENU = {
    'paciente_api.create_patient': 1, 'paciente_api.update_patient': 1, 'paciente_api.delete_patient': 1,
    'consultas.incluir_consulta_paciente': 1, 'consultas.organizar_consulta_local': 1,
    'exame_api.create_exam': 1,
    'exame_api.update_exam': 1, 'exame_api.delete_exam': 1,
    'agenda_api.create_appointment': 2, 'agenda_api.update_appointment': 2,
    'agenda_api.delete_appointment': 2, 'agenda_api.request_appointment_confirmation': 2,
    'agenda_api.request_email_confirmation': 2, 'agenda_api.request_whatsapp_confirmation': 2,
    'plano_api.create_plan': 3, 'plano_api.update_plan': 3, 'plano_api.delete_plan': 3,
    'prof_saude_api.create_anamnese': 4, 'prof_saude_api.update_anamnese': 4,
    'prof_saude_api.delete_anamnese': 4,
    'faturamento_api.import_from_agenda': 5, 'faturamento_api.create_payment': 5,
    'faturamento_api.update_payment': 5, 'faturamento_api.delete_payment': 5,
    'faturamento_api.duplicate_next_month': 5,
    'clinica_api.create_clinica': 7, 'clinica_api.update_clinica': 7, 'clinica_api.delete_clinica': 7,
    'prof_saude_api.create_profissional': 8, 'prof_saude_api.update_profissional': 8,
    'prof_saude_api.delete_profissional': 8,
    'usuario_api.create_usuario': 9, 'usuario_api.update_usuario': 9, 'usuario_api.delete_usuario': 9,
    'procedimento_api.create_procedure': 10, 'procedimento_api.update_procedure': 10,
    'procedimento_api.delete_procedure': 10,
    'configuracao_api.save_configuration': 11, 'configuracao_api.test_email_configuration': 11,
    'perfil_api.create_perfil': 14, 'perfil_api.update_perfil': 14, 'perfil_api.delete_perfil': 14,
    'empresa_api.create_empresa': 15, 'empresa_api.update_empresa': 15,
    'empresa_api.create_subscription_plan': 15, 'empresa_api.update_subscription_plan': 15,
}

ALWAYS_EDITABLE_MENU_IDS = {1, 2, 3, 4}


def _ensure_core_menu_permissions(permissions):
    normalized = list(permissions or [])
    by_menu = {}
    for index, value in enumerate(normalized):
        parts = str(value or '').strip().upper().split('-')
        if len(parts) == 3 and parts[0].isdigit():
            by_menu[int(parts[0])] = index
    for menu_id in ALWAYS_EDITABLE_MENU_IDS:
        permission = f'{menu_id}-AM-ET'
        if menu_id in by_menu:
            normalized[by_menu[menu_id]] = permission
        else:
            normalized.append(permission)
    return normalized

PROFILE_VIEW_ENDPOINTS = {
    'consultas.consultas_paciente': 'verhist',
    'consultas.incluir_consulta_paciente': 'verhist',
    'consultas.organizar_consulta_local': 'verhist',
    'exame_api.list_exams': 'verexame',
    'exame_api.create_exam': 'verexame',
    'exame_api.update_exam': 'verexame',
    'exame_api.delete_exam': 'verexame',
    'exame_api.exam_image': 'verexame',
}


def _plan_flag(value):
    return str(value or '').strip().upper() in ('S', 'SIM', '1', 'TRUE')


def _load_plan_capabilities(company_id, force=False):
    keys = ('plan_financeiro', 'plan_teleconsulta', 'plan_ditadovoz')
    if not force and all(key in session for key in keys):
        return {key: bool(session.get(key)) for key in keys}
    capabilities = {key: True for key in keys}
    try:
        company_id = int(company_id or 0)
    except (TypeError, ValueError):
        company_id = 0
    if company_id > 0:
        connection = get_db_connection()
        try:
            with connection.cursor() as cursor:
                cursor.execute('''
                    SELECT plano."Financeiro", plano."Teleconsulta", plano.ditadovoz
                    FROM public.ic_empresa_geral empresa
                    LEFT JOIN public.ic_plano_geral plano ON plano.idplano = empresa.idplano
                    WHERE empresa.idempresa = %s
                    LIMIT 1
                ''', (company_id,))
                row = cursor.fetchone()
            if row:
                capabilities = {
                    'plan_financeiro': _plan_flag(row[0]),
                    'plan_teleconsulta': _plan_flag(row[1]),
                    'plan_ditadovoz': _plan_flag(row[2]),
                }
        finally:
            connection.close()
    session.update(capabilities)
    return capabilities


@app.before_request
def require_plan_feature_permission():
    if not _has_valid_session():
        return None
    endpoint = request.endpoint or ''
    if endpoint != 'faturamento_html' and not endpoint.startswith('faturamento_api.'):
        return None
    try:
        capabilities = _load_plan_capabilities(session.get('idempresa'))
    except Exception:
        logging.exception('Não foi possível validar os recursos do plano.')
        capabilities = {'plan_financeiro': False}
    if capabilities.get('plan_financeiro'):
        return None
    message = 'O plano da empresa não permite acesso ao Financeiro.'
    if request.path.startswith('/api/'):
        return jsonify({'success': False, 'message': message}), 403
    return message, 403


def _profile_view_allowed(field_name):
    cache_key = 'profile_' + field_name
    connection = get_db_connection(session.get('db_path') or None)
    try:
        with connection.cursor() as cursor:
            cursor.execute('''
                SELECT COALESCE(perfil.{}::text, 'SIM')
                FROM public.ic_usuario_geral usuario
                INNER JOIN public.ic_perfil_geral perfil ON perfil.idperfil = usuario.idperfil
                WHERE usuario.idusuario = %s
                LIMIT 1
            '''.format(field_name), (session.get('idusuario'),))
            row = cursor.fetchone()
    finally:
        connection.close()
    allowed = bool(row) and str(row[0] or '').strip().upper() == 'SIM'
    session[cache_key] = allowed
    return allowed


@app.before_request
def require_profile_view_permission():
    field_name = PROFILE_VIEW_ENDPOINTS.get(request.endpoint)
    if not field_name or not _has_valid_session():
        return None
    try:
        allowed = _profile_view_allowed(field_name)
    except Exception:
        logging.exception('Não foi possível validar a permissão de visualização do perfil.')
        allowed = False
    if allowed:
        return None
    resource = 'histórico clínico' if field_name == 'verhist' else 'histórico de exames'
    return jsonify({
        'success': False,
        'message': 'Seu perfil não permite visualizar o {}.'.format(resource),
    }), 403


@app.before_request
def require_menu_edit_permission():
    menu_id = EDIT_ENDPOINT_MENU.get(request.endpoint)
    if not menu_id or not _has_valid_session():
        return None
    if menu_id in ALWAYS_EDITABLE_MENU_IDS:
        return None
    profile_name = (session.get('perfil') or '').strip().upper()
    is_health_professional = profile_name in (
        'PROFSAÚDE', 'PROFSAUDE', 'PROF. SAÚDE', 'PROF. SAUDE'
    )
    if request.endpoint == 'consultas.incluir_consulta_paciente' and is_health_professional:
        return None
    permissions = session.get('menu_permissions') or []
    for value in permissions:
        parts = str(value or '').upper().split('-')
        if len(parts) == 3 and parts[0] == str(menu_id) and parts[2] == 'NET':
            return jsonify({
                'success': False,
                'message': 'Seu perfil possui acesso somente para visualização neste menu.',
            }), 403
    return None

# Validar configuração inicial e falhar com mensagem clara se estiver incorreta
validation_errors = config.validate_config()
if validation_errors:
    for err in validation_errors:
        print('Configuration error:', err)
    print('Corrija as variáveis de ambiente conforme mensagens acima e reinicie a aplicação.')
    sys.exit(1)
app.register_blueprint(consultas_bp)
app.register_blueprint(consulta_paciente_bp)
app.register_blueprint(agenda_bp)
app.register_blueprint(agenda_api_bp)
app.register_blueprint(paciente_api_bp)
app.register_blueprint(plano_api_bp)
app.register_blueprint(prof_saude_api_bp)
app.register_blueprint(clinica_api_bp)
app.register_blueprint(usuario_api_bp)
app.register_blueprint(configuracao_api_bp)
app.register_blueprint(baileys_api_bp)
app.register_blueprint(exame_api_bp)
app.register_blueprint(perfil_api_bp)
app.register_blueprint(empresa_api_bp)
app.register_blueprint(procedimento_api_bp)
app.register_blueprint(faturamento_api_bp)
app.register_blueprint(mensagens_api_bp)
app.register_blueprint(internal_chat_api_bp)

# Serializer para tokens de redefinição de senha
serializer = URLSafeTimedSerializer(app.secret_key)


def send_email(to_address, subject, body, html_body=None):
    """Envia um e-mail usando as configurações em `config`.
    Retorna True se enviado com sucesso, False caso contrário.
    """
    # Se SMTP não estiver configurado, não tenta enviar
    if not getattr(config, 'SMTP_HOST', ''):
        logging.info('SMTP não configurado; pulando envio de e-mail.')
        return False
    try:
        msg = EmailMessage()
        msg['From'] = config.SMTP_FROM
        msg['To'] = to_address
        msg['Subject'] = subject
        msg.set_content(body)
        if html_body:
            msg.add_alternative(html_body, subtype='html')

        if config.SMTP_USE_SSL:
            server = smtplib.SMTP_SSL(config.SMTP_HOST, config.SMTP_PORT, timeout=10)
        else:
            server = smtplib.SMTP(config.SMTP_HOST, config.SMTP_PORT, timeout=10)
        server.ehlo()
        if config.SMTP_USE_TLS and not config.SMTP_USE_SSL:
            server.starttls()
            server.ehlo()
        if config.SMTP_USER and config.SMTP_PASS:
            server.login(config.SMTP_USER, config.SMTP_PASS)
        server.send_message(msg)
        server.quit()
        logging.info(f'E-mail enviado para {to_address}')
        log_sent_message('Email Manual', to_address, content=body)
        return True
    except Exception as e:
        logging.exception('Falha ao enviar e-mail:')
        return False



# Rota para servir consultas_paciente.html
@app.route('/consultas_paciente.html')
def consultas_paciente_html():
    return render_template('consultas_paciente.html')


@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    login = data.get('nome')
    senha = data.get('senha')
    if not login or not senha:
        return jsonify({'success': False, 'message': 'Nome e senha obrigatórios.'}), 400
    try:
        global db_path_global, usuario_global, empresa_global
        idusuario, idempresa, nome, db_path, empresa_nome, nome_medico, perfil = get_user_empresa_db(login, senha)
        if not idusuario or not db_path:
            return jsonify({'success': False, 'message': 'Nome ou senha inválidos ou empresa inativa.'}), 401
        # Define variáveis globais
        if (perfil or '').strip().upper() != 'MASTER':
            usage_allowed, limit_date = get_company_usage_limit(idempresa)
            if not usage_allowed:
                session.clear()
                return jsonify({
                    'success': False,
                    'message': 'O prazo de uso do plano terminou em {}. Entre em contato com o suporte.'.format(
                        limit_date.strftime('%d/%m/%Y')
                    ),
                }), 403
        db_path_global = db_path
        usuario_global = nome
        empresa_global = empresa_nome
        # Testa conexão com banco do usuário
        try:
            con_user = get_db_connection(db_path)
            con_user.close()
        except Exception as e:
            session.clear()
            return jsonify({'success': False, 'message': f'Erro ao conectar ao banco da empresa: {str(e)}'}), 500
        session.clear()
        session['db_path'] = db_path
        session['idusuario'] = idusuario
        session['idempresa'] = idempresa
        # Alias mantido para os pontos legados que já procuram codclin.
        session['codclin'] = idempresa
        session['empresa_nome'] = empresa_nome
        session['nome_medico'] = nome_medico
        session['usuario'] = nome
        session['perfil'] = perfil
        session['authenticated'] = True
        session.permanent = True
        _load_plan_capabilities(idempresa, force=True)
        return jsonify({
            'success': True,
            'message': 'Login realizado com sucesso.',
            'nome': nome,
            'idusuario': idusuario,
            'idempresa': idempresa,
            'db_path': db_path,
            'empresa_nome': empresa_nome,
            'nome_medico': nome_medico,
            'perfil': perfil
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'success': True})


@app.route('/api/change-password', methods=['POST'])
def change_password():
    data = request.json
    nome = data.get('nome')
    senha_atual = data.get('senhaAtual')
    nova_senha = data.get('novaSenha')
    if not nome or not senha_atual or not nova_senha:
        return jsonify({'success': False, 'message': 'Usuário, senha atual e nova senha obrigatórios.'}), 400
    try:
        con = get_db_connection()
        cur = con.cursor()
        # Verifica se a senha atual está correta na tabela ic_usuario_geral (campo login/senha)
        try:
            cur.execute("SELECT idusuario FROM ic_usuario_geral WHERE login=%s AND senha=%s AND ativo=TRUE", (nome, senha_atual))
            row = cur.fetchone()
        except Exception:
            con.close()
            return jsonify({'success': False, 'message': 'Erro ao verificar usuário no banco.'}), 500
        if not row:
            con.close()
            return jsonify({'success': False, 'message': 'Senha atual incorreta.'}), 401
        idusuario = row[0]
        # Atualiza a senha no ic_usuario_geral
        cur.execute("UPDATE ic_usuario_geral SET senha=%s WHERE idusuario=%s", (nova_senha, idusuario))
        con.commit()
        # Independente do rowcount, se não deu erro e passou pela verificação da senha, considera sucesso
        con.close()
        return jsonify({'success': True, 'message': 'Senha alterada com sucesso!'}), 200
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500


# --- Recuperação de senha ---
@app.route('/esqueci-senha', methods=['GET'])
def esqueci_senha_form():
    return render_template('esqueci_senha.html')


@app.route('/esqueci-senha', methods=['POST'])
def esqueci_senha_post():
    # Aceita form-urlencoded ou JSON
    email = request.form.get('email') if request.form else (request.json and request.json.get('email'))
    if not email:
        return jsonify({'success': False, 'message': 'E-mail obrigatório.'}), 400
    try:
        con = get_db_connection()
        cur = con.cursor()
        user = None
        # Tenta localizar por coluna email; se a consulta falhar (ex.: coluna não existe), faz rollback
        try:
            cur.execute("SELECT idusuario, login, nome, email FROM ic_usuario_geral WHERE email=%s AND ativo=TRUE", (email,))
            user = cur.fetchone()
        except Exception as e:
            # A consulta pode ter deixado a transação em estado abortado; desfaz antes da segunda tentativa
            try:
                con.rollback()
            except Exception:
                pass
            try:
                cur.execute("SELECT idusuario, login, nome FROM ic_usuario_geral WHERE login=%s AND ativo=TRUE", (email,))
                user = cur.fetchone()
            except Exception as e2:
                con.close()
                return jsonify({'success': False, 'message': f'Erro ao acessar o banco: {str(e2)}'}), 500
        con.close()
    except Exception as e:
        return jsonify({'success': False, 'message': f'Erro ao acessar o banco: {str(e)}'}), 500
    # Não revelar se o usuário existe; sempre retornar mensagem positiva
    if not user:
        print(f'[Password Reset] nenhum usuário encontrado para: {email}')
        return jsonify({'success': True, 'message': 'Se o e-mail estiver cadastrado, você receberá instruções para redefinir sua senha.'})
    idusuario = user[0]
    token = serializer.dumps({'idusuario': idusuario}, salt='password-reset-salt')
    reset_link = f"{request.url_root.rstrip('/')}/reset-password/{token}"
    subject = 'MedSoft - Redefinição de senha'
    body = f"Você solicitou a redefinição de senha. Acesse o link abaixo para criar uma nova senha (válido por 1 hora):\n\n{reset_link}\n\nSe você não solicitou, desconsidere este e-mail."
    html = f"<p>Você solicitou a redefinição de senha. Clique no link abaixo para criar uma nova senha (válido por 1 hora):</p><p><a href=\"{reset_link}\">Redefinir minha senha</a></p>"
    sent = send_email(email, subject, body, html_body=html)
    if not sent:
        # fallback: mostra link no console e retorna debug_link durante desenvolvimento
        print(f'[Password Reset] Link para {email}: {reset_link}')
        return jsonify({'success': True, 'message': 'Se o e-mail estiver cadastrado, você receberá instruções para redefinir sua senha.', 'debug_link': reset_link})
    return jsonify({'success': True, 'message': 'Se o e-mail estiver cadastrado, você receberá instruções para redefinir sua senha.'})


@app.route('/reset-password/<token>', methods=['GET'])
def reset_password_form(token):
    return render_template('reset_senha.html', token=token)


@app.route('/reset-password', methods=['POST'])
def reset_password_post():
    token = request.form.get('token') if request.form else (request.json and request.json.get('token'))
    nova_senha = request.form.get('nova_senha') if request.form else (request.json and request.json.get('nova_senha'))
    if not token or not nova_senha:
        return jsonify({'success': False, 'message': 'Token e nova senha obrigatórios.'}), 400
    try:
        data = serializer.loads(token, salt='password-reset-salt', max_age=3600)
        idusuario = data.get('idusuario')
    except SignatureExpired:
        return jsonify({'success': False, 'message': 'Token expirado.'}), 400
    except BadSignature:
        return jsonify({'success': False, 'message': 'Token inválido.'}), 400
    try:
        con = get_db_connection()
        cur = con.cursor()
        cur.execute("UPDATE ic_usuario_geral SET senha=%s WHERE idusuario=%s", (nova_senha, idusuario))
        con.commit()
        con.close()
        return jsonify({'success': True, 'message': 'Senha redefinida com sucesso.'})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Erro ao atualizar a senha: {str(e)}'}), 500





# Rota para servir o login.html como página inicial
@app.route('/')
def index():
    return render_template(
        'login.html',
        build_datetime=BUILD_DATETIME,
        build_version=BUILD_VERSION,
    )

# Rota para servir arquivos HTML da pasta frontend


# Rotas para servir os outros templates diretamente
@app.route('/principal.html')
def principal():
    return render_template('principal.html')

@app.route('/menu.html')
def menu():
    db_path = session.get('db_path', '')
    nome_medico = session.get('nome_medico', '')
    perfil = (session.get('perfil') or '').strip().upper()
    perfil_display = (session.get('perfil') or '').strip()
    try:
        company_id = int(session.get('idempresa') or session.get('codclin') or 0)
    except (TypeError, ValueError):
        company_id = 0
    show_clinic_header = perfil != 'MASTER' or company_id > 0
    company_plan_name = ''
    plan_capabilities = _load_plan_capabilities(company_id, force=True)
    menu_permissions = [f'{number}-AM-ET' for number in range(1, 16)]
    try:
        connection = get_db_connection()
        cursor = connection.cursor()
        cursor.execute('''
            SELECT menu1, menu2, menu3, menu4, menu5, menu6, menu7, menu8,
                   menu9, menu10, menu11, menu12, menu13, menu14, menu15,
                   COALESCE(verhist::text, 'SIM'), COALESCE(verexame::text, 'SIM')
            FROM public.ic_perfil_geral perfil
            INNER JOIN public.ic_usuario_geral usuario ON usuario.idperfil = perfil.idperfil
            WHERE usuario.idusuario = %s
            LIMIT 1
        ''', (session.get('idusuario'),))
        permission_row = cursor.fetchone()
        connection.close()
        if permission_row:
            menu_permissions = [
                str(value or f'{index}-AM-ET').strip().upper()
                for index, value in enumerate(permission_row[:15], 1)
            ]
            session['profile_verhist'] = str(permission_row[15] or '').strip().upper() == 'SIM'
            session['profile_verexame'] = str(permission_row[16] or '').strip().upper() == 'SIM'
        menu_permissions = _ensure_core_menu_permissions(menu_permissions)
        session['menu_permissions'] = menu_permissions
    except Exception:
        logging.exception('Não foi possível carregar as permissões de menu do perfil.')
    if show_clinic_header and company_id > 0:
        try:
            connection = get_db_connection()
            cursor = connection.cursor()
            cursor.execute('''
                SELECT COALESCE(plano.plano, '')
                FROM public.ic_empresa_geral empresa
                LEFT JOIN public.ic_plano_geral plano ON plano.idplano = empresa.idplano
                WHERE empresa.idempresa = %s
                LIMIT 1
            ''', (company_id,))
            plan_row = cursor.fetchone()
            company_plan_name = (plan_row[0] if plan_row else '') or ''
            connection.close()
        except Exception:
            logging.exception('Não foi possível carregar o plano da empresa.')
    return render_template(
        'menu.html',
        db_path=db_path,
        nome_usuario=session.get('usuario', ''),
        perfil_usuario=perfil_display.title() if perfil_display else '',
        empresa_id=company_id if show_clinic_header and company_id > 0 else '',
        empresa_nome=session.get('empresa_nome', '') if show_clinic_header else '',
        empresa_plano=company_plan_name,
        plan_financeiro=plan_capabilities.get('plan_financeiro', True),
        plan_teleconsulta=plan_capabilities.get('plan_teleconsulta', True),
        plan_ditadovoz=plan_capabilities.get('plan_ditadovoz', True),
        nome_medico=nome_medico,
        perfil=perfil,
        menu_permissions=menu_permissions,
        profile_verhist=session.get('profile_verhist', True),
        profile_verexame=session.get('profile_verexame', True),
        build_datetime=BUILD_DATETIME,
        build_version=BUILD_VERSION,
    )

@app.route('/consulta_paciente.html')
def consulta_paciente_html():
    return render_template('consulta_paciente.html', build_version=BUILD_VERSION)


@app.route('/plano')
def plano_html():
    return render_template('plano.html', build_version=BUILD_VERSION)


@app.route('/prof-saude')
def prof_saude_html():
    return render_template('prof_saude.html', build_version=BUILD_VERSION)


@app.route('/clinica')
def clinica_html():
    return render_template('clinica.html', build_version=BUILD_VERSION)


@app.route('/anamnese')
def anamnese_html():
    return render_template('anamnese.html', build_version=BUILD_VERSION)


@app.route('/usuario')
def usuario_html():
    return render_template('usuario.html', build_version=BUILD_VERSION)


@app.route('/procedimentos')
def procedimentos_html():
    return render_template('procedimentos.html', build_version=BUILD_VERSION)


@app.route('/faturamento')
def faturamento_html():
    return render_template('faturamento.html', build_version=BUILD_VERSION)


@app.route('/relatorios')
def relatorios_html():
    return render_template(
        'relatorios.html',
        build_version=BUILD_VERSION,
        empresa_nome=session.get('empresa_nome', ''),
    )


@app.route('/help.html')
def help_html():
    help_template = os.path.join(template_folder, 'help.html')
    if os.path.exists(help_template):
        return render_template('help.html', build_version=BUILD_VERSION)
    return (
        '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8">'
        '<style>body{font-family:Segoe UI,Arial,sans-serif;margin:16px;color:#18304f;line-height:1.45}'
        'h1{font-size:20px;color:#357ae8}</style></head><body>'
        '<h1>Ajuda</h1><p>Arquivo help.html não encontrado.</p>'
        '<p>Coloque o arquivo em <strong>templates/help.html</strong> para exibir o conteúdo de ajuda.</p>'
        '</body></html>'
    )


@app.route('/configuracao')
def configuracao_html():
    return render_template('configuracao.html', build_version=BUILD_VERSION)


@app.route('/config-email')
def config_email_html():
    return render_template('configuracao.html', build_version=BUILD_VERSION)


@app.route('/config-whatsapp')
def config_whatsapp_html():
    return render_template('configuracao_whatsapp.html', build_version=BUILD_VERSION)


@app.route('/mensagens-enviadas')
def mensagens_enviadas_html():
    return render_template('mensagens_enviadas.html', build_version=BUILD_VERSION)


@app.route('/crm-whatsapp')
def crm_whatsapp_html():
    return render_template('crm_whatsapp.html', build_version=BUILD_VERSION)


@app.route('/crm-email')
def crm_email_html():
    return render_template('crm_email.html', build_version=BUILD_VERSION)


@app.route('/perfil')
def perfil_html():
    return render_template('perfil.html', build_version=BUILD_VERSION)


@app.route('/empresa')
def empresa_html():
    return render_template('empresa.html', build_version=BUILD_VERSION)


@app.route('/plano-empresa')
def plano_empresa_html():
    return render_template('plano_empresa.html', build_version=BUILD_VERSION)


# Import consulta_paciente to register /api/consulta-paciente endpoint
import consulta_paciente

if __name__ == '__main__':
    import socket
    import threading
    import webbrowser

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.settimeout(0.5)
        if probe.connect_ex(('127.0.0.1', 8072)) == 0:
            print('O MedSoft ja esta em execucao na porta 8072. Feche a instancia antiga antes de abrir outra.')
            webbrowser.open('http://localhost:8072')
            sys.exit(0)

    from bounce_robot import start_bounce_robot
    from email_robot import start_email_robot

    start_email_robot(app)
    start_bounce_robot(app)
    threading.Timer(1.0, lambda: webbrowser.open('http://localhost:8072')).start()
    app.run(host='0.0.0.0', port=8072, debug=False, use_reloader=False)
