(function () {
    function headers() {
        return {'Content-Type': 'application/json'};
    }

    function formatDate(value, includeDate) {
        if (!value) return '';
        var date = new Date(value);
        if (Number.isNaN(date.getTime())) return value;
        return new Intl.DateTimeFormat('pt-BR', includeDate
            ? {dateStyle: 'short', timeStyle: 'short'}
            : {hour: '2-digit', minute: '2-digit'}).format(date);
    }

    function previewText(item) {
        if (item.ultima_mensagem) return item.ultima_mensagem.replace(/\s+/g, ' ').trim();
        return item.registro_legado ? 'Mensagem antiga sem conteúdo armazenado' : 'Sem conteúdo';
    }

    function init() {
        var page = document.getElementById('crm-whatsapp-page');
        if (!page || page.dataset.initialized === 'true') return;
        page.dataset.initialized = 'true';
        var list = document.getElementById('crm-conversations-list');
        var chat = document.getElementById('crm-chat-panel');
        var search = document.getElementById('crm-conversations-search');
        var conversations = [];
        var selectedDestination = '';
        var selectedPatient = null;

        async function loadConnection() {
            var badge = document.getElementById('crm-connected-phone');
            try {
                var status = await CrudUI.request('/api/whatsapp/connection', {method:'GET', headers:headers()});
                badge.classList.toggle('is-offline', !status.connected);
                badge.innerHTML = status.connected
                    ? '<i class="fa fa-phone"></i> ' + CrudUI.escapeHtml(status.phone || 'WhatsApp conectado')
                    : '<i class="fa fa-circle-exclamation"></i> WhatsApp desconectado';
            } catch (error) {
                badge.classList.add('is-offline');
                badge.innerHTML = '<i class="fa fa-circle-exclamation"></i> Serviço indisponível';
            }
        }

        function selectedPatientFromTable() {
            var checked = page.querySelector('[data-crm-patient-selector] [data-patient-check]:checked');
            return checked ? {name: checked.dataset.patientName || '', phone: checked.dataset.patientPhone || ''} : null;
        }

        function showSelectedPatient(patient) {
            selectedPatient = patient || null;
            var phone = patient && patient.phone ? patient.phone : '';
            document.getElementById('crm-direct-phone').value = phone;
            var display = document.getElementById('crm-direct-selected');
            display.innerHTML = phone
                ? '<i class="fa fa-user"></i><div><strong>' + CrudUI.escapeHtml(patient.name || 'Paciente selecionado') + '</strong><span>' + CrudUI.escapeHtml(phone) + '</span></div>'
                : '<i class="fa fa-user"></i><div><strong>Selecione um paciente na lista acima</strong><span>O telefone cadastrado será utilizado automaticamente.</span></div>';
        }

        function activateTab(name) {
            page.querySelectorAll('[data-crm-whatsapp-tab]').forEach(function (button) { button.classList.toggle('is-active', button.dataset.crmWhatsappTab === name); });
            page.querySelectorAll('[data-crm-whatsapp-panel]').forEach(function (panel) { panel.classList.toggle('is-active', panel.dataset.crmWhatsappPanel === name); });
            if (name === 'contacts') loadContacts();
            if (name === 'direct') {
                var current = selectedPatientFromTable() || (window.MedsoftSelectedWhatsappPatients || [])[0];
                if (current) showSelectedPatient(current);
            }
        }

        async function loadContacts() {
            var container = document.getElementById('crm-whatsapp-contacts-list');
            container.innerHTML = '<div class="crud-loading">Carregando contatos do telefone...</div>';
            try {
                var data = await CrudUI.request('/api/whatsapp/contacts', {method: 'GET', headers: headers()});
                var contacts = data.contacts || [];
                container.dataset.contacts = JSON.stringify(contacts);
                renderContacts(contacts);
            } catch (error) { container.innerHTML = '<div class="crud-error">Não foi possível carregar os contatos do telefone. Reinicie o serviço Baileys e confirme sua conexão.</div>'; }
        }

        function renderContacts(contacts) {
            var container = document.getElementById('crm-whatsapp-contacts-list');
            var term = document.getElementById('crm-whatsapp-contact-search').value.trim().toLowerCase();
            contacts = contacts.filter(function(item) { return !term || (item.name + ' ' + item.phone).toLowerCase().indexOf(term) >= 0; });
            container.innerHTML = contacts.length ? contacts.map(function(item) { return '<button type="button" class="crm-phone-contact" data-contact-phone="' + CrudUI.escapeHtml(item.phone) + '"><i class="fa-brands fa-whatsapp"></i><span><strong>' + CrudUI.escapeHtml(item.name) + '</strong><small>' + CrudUI.escapeHtml(item.phone) + '</small></span></button>'; }).join('') : '<div class="crud-empty">Nenhum contato sincronizado pelo telefone.</div>';
        }

        async function loadReceived() {
            var phone = document.getElementById('crm-direct-phone').value.trim();
            var history = document.getElementById('crm-direct-history');
            if (!phone) { history.innerHTML = '<div class="crud-empty">Selecione um paciente na lista acima para consultar as mensagens.</div>'; return; }
            try {
                var data = await CrudUI.request('/api/whatsapp/received?phone=' + encodeURIComponent(phone), {method:'GET', headers:headers()});
                var items = data.messages || [];
                history.innerHTML = items.length ? items.map(function(item) { return '<article class="crm-chat-message is-incoming"><div class="crm-chat-message-text">' + CrudUI.escapeHtml(item.text) + '</div><div class="crm-chat-message-meta"><time>' + CrudUI.escapeHtml(formatDate(new Date(item.timestamp * 1000).toISOString(), true)) + '</time><span>Recebida</span></div></article>'; }).join('') : '<div class="crud-empty">Nenhuma mensagem recebida deste telefone desde que o serviço foi iniciado.</div>';
                history.scrollTop = history.scrollHeight;
            } catch(error) { history.innerHTML = '<div class="crud-error">' + CrudUI.escapeHtml(error.message) + '</div>'; }
        }

        async function sendDirect() {
            var tablePatient = selectedPatientFromTable();
            if (tablePatient) showSelectedPatient(tablePatient);
            var phone = document.getElementById('crm-direct-phone').value.trim();
            var message = document.getElementById('crm-direct-message').value.trim();
            if (!phone) { CrudUI.notify('Selecione um paciente com telefone na lista acima.', 'error'); return; }
            if (!message) { CrudUI.notify('Digite a mensagem.', 'error'); return; }
            try {
                await CrudUI.request('/api/whatsapp/send', {method:'POST',headers:headers(),body:JSON.stringify({phone:phone,message:message})});
                document.getElementById('crm-direct-message').value = '';
                CrudUI.notify('Mensagem enviada pelo Whatzap.');
                load(); loadReceived();
            } catch(error) { CrudUI.notify('Falha no envio: ' + (error.message || 'erro não identificado.'), 'error'); }
        }

        function renderConversations() {
            var term = search.value.trim().toLocaleLowerCase('pt-BR');
            var filtered = conversations.filter(function (item) {
                return !term || (item.paciente + ' ' + item.destino)
                    .toLocaleLowerCase('pt-BR').indexOf(term) !== -1;
            });
            if (!filtered.length) {
                list.innerHTML = '<div class="crud-empty">Nenhuma conversa encontrada.</div>';
                return;
            }
            list.innerHTML = filtered.map(function (item) {
                var active = item.destino === selectedDestination ? ' is-active' : '';
                var error = item.enviado === 'Não' ? '<i class="fa fa-circle-exclamation crm-conversation-error"></i>' : '';
                return '<button type="button" class="crm-conversation' + active + '" data-destination="' +
                    CrudUI.escapeHtml(item.destino) + '"><span class="crm-conversation-avatar"><i class="fa fa-user"></i></span>' +
                    '<span class="crm-conversation-body"><span class="crm-conversation-title">' +
                    CrudUI.escapeHtml(item.paciente || item.destino || 'Sem destinatário') + '</span>' +
                    '<span class="crm-conversation-preview">' + CrudUI.escapeHtml(previewText(item)) + '</span></span>' +
                    '<span class="crm-conversation-side"><time>' + CrudUI.escapeHtml(formatDate(item.ultima_data, true)) +
                    '</time><span>' + error + CrudUI.escapeHtml(item.total) + '</span></span></button>';
            }).join('');
        }

        async function openConversation(destination) {
            selectedDestination = destination;
            renderConversations();
            var conversation = conversations.find(function (item) { return item.destino === destination; }) || {};
            chat.innerHTML = '<div class="crud-loading">Carregando histórico...</div>';
            try {
                var data = await CrudUI.request('/api/crm/whatsapp/historico', {
                    method: 'POST', headers: headers(), body: JSON.stringify({destino: destination})
                });
                var messages = data.mensagens || [];
                var bubbles = messages.map(function (message) {
                    var failed = message.enviado === 'Não';
                    var content = message.conteudo || 'Mensagem antiga: o conteúdo original não foi armazenado.';
                    return '<article class="crm-chat-message is-outgoing' + (failed ? ' is-error' : '') + '">' +
                        '<div class="crm-chat-message-text">' + CrudUI.escapeHtml(content) + '</div>' +
                        '<div class="crm-chat-message-meta"><time>' + CrudUI.escapeHtml(formatDate(message.datahora, true)) +
                        '</time><span>' + (failed ? '<i class="fa fa-circle-xmark"></i> Falha' :
                            '<i class="fa fa-check-double"></i> Enviada') + '</span></div>' +
                        (failed && message.motivoerro ? '<div class="crm-chat-error">' +
                            CrudUI.escapeHtml(message.motivoerro) + '</div>' : '') + '</article>';
                }).join('') || '<div class="crud-empty">Nenhuma mensagem nesta conversa.</div>';
                chat.innerHTML = '<header class="crm-chat-header"><span class="crm-conversation-avatar"><i class="fa fa-user"></i></span>' +
                    '<div><h3>' + CrudUI.escapeHtml(conversation.paciente || destination) + '</h3><p>' +
                    CrudUI.escapeHtml(destination) + '</p></div></header><div class="crm-chat-history" id="crm-chat-history">' +
                    bubbles + '</div>';
                var history = document.getElementById('crm-chat-history');
                history.scrollTop = history.scrollHeight;
            } catch (error) {
                chat.innerHTML = '<div class="crud-error">' + CrudUI.escapeHtml(error.message || 'Erro ao carregar histórico.') + '</div>';
            }
        }

        async function load() {
            loadConnection();
            list.innerHTML = '<div class="crud-loading">Carregando conversas...</div>';
            try {
                var data = await CrudUI.request('/api/crm/whatsapp/conversas', {method: 'GET', headers: headers()});
                conversations = data.conversas || [];
                renderConversations();
                if (selectedDestination && conversations.some(function (item) { return item.destino === selectedDestination; })) {
                    openConversation(selectedDestination);
                }
            } catch (error) {
                list.innerHTML = '<div class="crud-error">' + CrudUI.escapeHtml(error.message || 'Erro ao carregar conversas.') + '</div>';
            }
        }

        list.addEventListener('click', function (event) {
            var button = event.target.closest('[data-destination]');
            if (button) openConversation(button.dataset.destination);
        });
        search.addEventListener('input', renderConversations);
        document.getElementById('crm-whatsapp-refresh').onclick = load;
        page.querySelectorAll('[data-crm-whatsapp-tab]').forEach(function(button) { button.onclick = function() { activateTab(button.dataset.crmWhatsappTab); }; });
        document.getElementById('crm-whatsapp-contact-search').oninput = function() { var value=document.getElementById('crm-whatsapp-contacts-list').dataset.contacts; if(value) renderContacts(JSON.parse(value)); };
        document.getElementById('crm-whatsapp-contacts-list').onclick = function(event) { var button=event.target.closest('[data-contact-phone]'); if(button){showSelectedPatient({name:button.innerText.split('\n')[0],phone:button.dataset.contactPhone});activateTab('direct');loadReceived();} };
        page.addEventListener('crm:patient-selection', function(event) {
            if (event.detail.channel !== 'whatsapp') return;
            showSelectedPatient((event.detail.patients || [])[0] || null);
        });
        document.getElementById('crm-direct-send').onclick = sendDirect;
        document.getElementById('crm-direct-refresh').onclick = loadReceived;
        load();
    }

    window.CrmWhatsapp = {init: init};
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
}());
