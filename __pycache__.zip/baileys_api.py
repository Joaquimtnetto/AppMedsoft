import json
import urllib.error
import urllib.request

from flask import Blueprint, jsonify, request, session

import config
from message_log import log_sent_message


baileys_api_bp = Blueprint('baileys_api', __name__)


def _company_id():
    value = session.get('idempresa') or session.get('codclin')
    try:
        value = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError('Empresa da sessão não identificada.') from exc
    if value <= 0:
        raise ValueError('Selecione uma empresa antes de conectar o WhatsApp.')
    return value


def _service_request(method, path, payload=None):
    if not config.BAILEYS_SERVICE_TOKEN:
        raise RuntimeError('MEDSOFT_BAILEYS_TOKEN não foi configurado no servidor.')
    body = json.dumps(payload).encode('utf-8') if payload is not None else None
    service_request = urllib.request.Request(
        config.BAILEYS_SERVICE_URL + path,
        method=method,
        data=body,
        headers={
            'Authorization': 'Bearer ' + config.BAILEYS_SERVICE_TOKEN,
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        },
    )
    try:
        with urllib.request.urlopen(service_request, timeout=30) as response:
            return json.loads(response.read().decode('utf-8'))
    except urllib.error.HTTPError as exc:
        try:
            detail = json.loads(exc.read().decode('utf-8')).get('message')
        except (ValueError, AttributeError):
            detail = None
        raise RuntimeError(detail or 'O serviço do WhatsApp recusou a solicitação.') from exc
    except (urllib.error.URLError, TimeoutError) as exc:
        raise RuntimeError('O serviço de conexão do WhatsApp não está disponível.') from exc


def send_baileys_text(company_id, phone, message):
    try:
        company_id = int(company_id)
    except (TypeError, ValueError) as exc:
        raise ValueError('Empresa não identificada para o envio.') from exc
    if company_id <= 0:
        raise ValueError('Empresa não identificada para o envio.')
    phone_digits = ''.join(character for character in str(phone or '') if character.isdigit())
    if len(phone_digits) in (10, 11):
        phone_digits = '55' + phone_digits
    return _service_request(
        'POST', '/sessions/{}/messages/text'.format(company_id),
        {'phone': phone_digits, 'text': message},
    )


def _digits(value):
    return ''.join(character for character in str(value or '') if character.isdigit())


def _merge_contacts(*groups):
    merged = {}
    for contacts in groups:
        for item in contacts or []:
            jid = item.get('jid') or ''
            if item.get('isGroup') or str(jid).endswith('@g.us'):
                key = jid or item.get('phone') or item.get('name')
                if not key:
                    continue
                current = merged.get(key) or {}
                merged[key] = {
                    'jid': jid or current.get('jid') or key,
                    'phone': item.get('phone') or current.get('phone') or key,
                    'name': item.get('name') or current.get('name') or key,
                    'source': item.get('source') or current.get('source') or 'baileys',
                    'isGroup': True,
                }
                continue
            phone = _digits(item.get('phone'))
            if not phone:
                continue
            if len(phone) in (10, 11):
                phone = '55' + phone
            current = merged.get(phone) or {}
            merged[phone] = {
                'jid': item.get('jid') or current.get('jid') or '{}@s.whatsapp.net'.format(phone),
                'phone': phone,
                'name': item.get('name') or current.get('name') or phone,
                'source': item.get('source') or current.get('source') or 'baileys',
            }
    return sorted(merged.values(), key=lambda item: item['name'].lower())


@baileys_api_bp.get('/api/whatsapp/connection')
def whatsapp_connection():
    try:
        return jsonify(_service_request('GET', '/sessions/{}/status'.format(_company_id())))
    except (ValueError, RuntimeError) as exc:
        return jsonify({'success': False, 'message': str(exc)}), 503


@baileys_api_bp.post('/api/whatsapp/disconnect')
def whatsapp_disconnect():
    try:
        return jsonify(_service_request('POST', '/sessions/{}/disconnect'.format(_company_id())))
    except (ValueError, RuntimeError) as exc:
        return jsonify({'success': False, 'message': str(exc)}), 503


@baileys_api_bp.post('/api/whatsapp/reset')
def whatsapp_reset():
    try:
        return jsonify(_service_request('POST', '/sessions/{}/reset'.format(_company_id())))
    except (ValueError, RuntimeError) as exc:
        return jsonify({'success': False, 'message': str(exc)}), 503


@baileys_api_bp.post('/api/whatsapp/send')
def whatsapp_send():
    data = request.get_json(silent=True) or {}
    try:
        company_id = _company_id()
        result = send_baileys_text(company_id, data.get('phone'), data.get('message'))
        log_sent_message('Whatzap', result.get('recipient') or data.get('phone'), company_id=company_id,
                         message_id=result.get('messageId'), content=data.get('message'))
        return jsonify(result)
    except ValueError as exc:
        return jsonify({'success': False, 'message': str(exc)}), 400
    except RuntimeError as exc:
        return jsonify({'success': False, 'message': str(exc)}), 503


@baileys_api_bp.get('/api/whatsapp/contacts')
def whatsapp_contacts():
    try:
        company_id = _company_id()
        service_result = _service_request('GET', '/sessions/{}/contacts'.format(company_id))
        contacts = _merge_contacts(service_result.get('contacts'))
        return jsonify({'success': True, 'contacts': contacts})
    except (ValueError, RuntimeError) as exc:
        return jsonify({'success': False, 'message': str(exc)}), 503


@baileys_api_bp.get('/api/whatsapp/received')
def whatsapp_received():
    try:
        phone = ''.join(character for character in str(request.args.get('phone') or '') if character.isdigit())
        path = '/sessions/{}/messages/received'.format(_company_id())
        if phone:
            path += '?phone=' + phone
        return jsonify(_service_request('GET', path))
    except (ValueError, RuntimeError) as exc:
        return jsonify({'success': False, 'message': str(exc)}), 503
