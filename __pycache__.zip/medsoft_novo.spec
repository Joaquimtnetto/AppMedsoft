# -*- mode: python ; coding: utf-8 -*-

from datetime import datetime
from pathlib import Path


build_time = datetime.now().astimezone()
build_info = Path(SPECPATH) / 'backend' / 'build_info.py'
build_info.write_text(
    f"BUILD_DATETIME = '{build_time:%d/%m/%Y %H:%M}'\n"
    f"BUILD_VERSION = '{build_time:%Y%m%d%H%M%S}'\n",
    encoding='utf-8',
)


a = Analysis(
    ['backend\\medsoft_app.py'],
    pathex=['backend'],
    binaries=[],
    datas=[('templates', 'templates'), ('static', 'static')],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='medsoft_novo',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon='NONE',
    contents_directory='.',
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name='medsoft_novo',
)
